# Copyright Spack Project Developers. See COPYRIGHT file for details.
#
# SPDX-License-Identifier: (Apache-2.0 OR MIT)

import re
import socket

from spack_repo.builtin.build_systems.autotools import AutotoolsPackage

from spack.package import *


class Openssh(AutotoolsPackage):
    """OpenSSH is the premier connectivity tool for remote login with the
    SSH protocol. It encrypts all traffic to eliminate
    eavesdropping, connection hijacking, and other attacks. In
    addition, OpenSSH provides a large suite of secure tunneling
    capabilities, several authentication methods, and sophisticated
    configuration options.
    """

    homepage = "https://www.openssh.com/"
    url = "https://mirrors.sonic.net/pub/OpenBSD/OpenSSH/portable/openssh-8.7p1.tar.gz"

    tags = ["core-packages"]

    license("SSH-OpenSSH")

    version("10.3p1", sha256="56682a36bb92dcf4b4f016fd8ec8e74059b79a8de25c15d670d731e7d18e45f4")
    with default_args(deprecated=True):
        # https://www.cvedetails.com/cve/CVE-2026-35414/
        # https://www.cvedetails.com/cve/CVE-2026-35387/
        # https://www.cvedetails.com/cve/CVE-2026-35386/
        # https://www.cvedetails.com/cve/CVE-2026-35385/
        version(
            "10.2p1", sha256="ccc42c0419937959263fa1dbd16dafc18c56b984c03562d2937ce56a60f798b2"
        )
        # https://www.cvedetails.com/cve/CVE-2025-32728/
        # https://www.cvedetails.com/cve/CVE-2025-26466/
        # https://www.cvedetails.com/cve/CVE-2025-26465/
        version("9.9p1", sha256="b343fbcdbff87f15b1986e6e15d6d4fc9a7d36066be6b7fb507087ba8f966c02")
        # https://www.cvedetails.com/cve/CVE-2024-6387/
        version("9.8p1", sha256="dd8bd002a379b5d499dfb050dd1fa9af8029e80461f4bb6c523c49973f5a39f3")
        # https://www.cvedetails.com/cve/CVE-2024-39894/
        version("9.7p1", sha256="490426f766d82a2763fcacd8d83ea3d70798750c7bd2aff2e57dc5660f773ffd")
        version("9.6p1", sha256="910211c07255a8c5ad654391b40ee59800710dd8119dd5362de09385aa7a777c")
        # https://www.cvedetails.com/cve/CVE-2023-51385/
        # https://www.cvedetails.com/cve/CVE-2023-51384/
        # https://www.cvedetails.com/cve/CVE-2023-48795/
        version("9.5p1", sha256="f026e7b79ba7fb540f75182af96dc8a8f1db395f922bbc9f6ca603672686086b")
        version("9.4p1", sha256="3608fd9088db2163ceb3e600c85ab79d0de3d221e59192ea1923e23263866a85")
        # https://www.cvedetails.com/cve/CVE-2023-38408/
        version("9.3p1", sha256="e9baba7701a76a51f3d85a62c383a3c9dcd97fa900b859bc7db114c1868af8a8")

    variant(
        "gssapi", default=True, description="Enable authentication via Kerberos through GSSAPI"
    )

    depends_on("c", type="build")
    depends_on("cxx", type="build")

    depends_on("krb5+shared", when="+gssapi")
    depends_on("openssl")
    depends_on("libedit")
    depends_on("ncurses")
    depends_on("zlib-api")
    depends_on("py-twisted", type="test")
    depends_on("libxcrypt", type="link")

    maintainers("bernhardkaindl")
    executables = [
        "^ssh$",
        "^scp$",
        "^sftp$",
        "^ssh-add$",
        "^ssh-agent$",
        "^ssh-keygen$",
        "^ssh-keyscan$",
    ]

    # Both these patches are applied by Apple.
    # https://github.com/Homebrew/homebrew-core/blob/7aabdeb30506be9b01708793ae553502c115dfc8/Formula/o/openssh.rb#L40-L45
    patch(
        "https://raw.githubusercontent.com/Homebrew/patches/1860b0a745f1fe726900974845d1b0dd3c3398d6/openssh/patch-sandbox-darwin.c-apple-sandbox-named-external.diff",
        sha256="d886b98f99fd27e3157b02b5b57f3fb49f43fd33806195970d4567f12be66e71",
        when="@:9 platform=darwin",
    )

    # https://github.com/Homebrew/homebrew-core/blob/7aabdeb30506be9b01708793ae553502c115dfc8/Formula/o/openssh.rb#L48-L52C6
    patch(
        "https://raw.githubusercontent.com/Homebrew/patches/d8b2d8c2612fd251ac6de17bf0cc5174c3aab94c/openssh/patch-sshd.c-apple-sandbox-named-external.diff",
        sha256="3505c58bf1e584c8af92d916fe5f3f1899a6b15cc64a00ddece1dc0874b2f78f",
        when="@:9.7p1 platform=darwin",
    )
    # same as above, but against sshd-session.c instead of sshd.c
    patch(
        "https://raw.githubusercontent.com/Homebrew/patches/aa6c71920318f97370d74f2303d6aea387fb68e4/openssh/patch-sshd.c-apple-sandbox-named-external.diff",
        sha256="3f06fc03bcbbf3e6ba6360ef93edd2301f73efcd8069e516245aea7c4fb21279",
        when="@9.8p1:9 platform=darwin",
    )

    @classmethod
    def determine_version(cls, exe):
        output = Executable(exe)("-V", output=str, error=str).rstrip()
        match = re.search(r"OpenSSH_([^, ]+)", output)
        return match.group(1) if match else None

    def patch(self):
        # #29938: skip set-suid (also see man ssh-key-sign: it's not enabled by default)
        filter_file(r"\$\(INSTALL\) -m 4711", "$(INSTALL) -m711", "Makefile.in")
        # #39599: fix configure to parse zlib 1.3's version number to prevent build fail
        filter_file(r"if \(n != 3 && n != 4\)", "if (n < 2)", "configure")

        # Clang-based compilers (known at least 14-17) may randomly mis-compile
        # openssh according to this thread even when -fzero-call-used-regs=used:
        # https://www.mail-archive.com/openssh-bugs@mindrot.org/msg17461.html
        # Therefore, remove -fzero-call-used-regs=all for these compilers:
        spec = self.spec
        if spec.version < Version("9.6p1") and self.compiler.name.endswith(("clang", "oneapi")):
            filter_file("-fzero-call-used-regs=all", "", "configure")

    def configure_args(self):
        # OpenSSH's privilege separation path defaults to /var/empty. At
        # least newer versions want to create the directory during the
        # install step and fail if they cannot do so.
        args = ["--with-privsep-path={0}".format(self.prefix.var.empty)]
        if self.spec.satisfies("+gssapi"):
            args.append("--with-kerberos5=" + self.spec["krb5"].prefix)

        # Somehow creating pie executables fails with nvhpc, not with gcc.
        if "%nvhpc" in self.spec:
            args.append("--without-pie")
        return args

    def install(self, spec, prefix):
        """Install generates etc/sshd_config, but it fails in parallel mode"""
        make("install", parallel=False)

    def setup_build_environment(self, env: EnvironmentModifications) -> None:
        """Until spack supports a real implementation of setup_test_environment()"""
        if self.run_tests:
            self.setup_test_environment(env)

        # https://github.com/Homebrew/homebrew-core/blob/7aabdeb30506be9b01708793ae553502c115dfc8/Formula/o/openssh.rb#L65C31-L65C65
        # to use the MacOS patches
        if self.spec.platform == "darwin":
            env.append_flags("CPPFLAGS", "-D__APPLE_SANDBOX_NAMED_EXTERNAL__")

    def setup_test_environment(self, env: EnvironmentModifications):
        """Configure the regression test suite like Debian's openssh-tests package"""
        p = self.prefix
        j = join_path
        env.set("TEST_SSH_SSH", p.bin.ssh)
        env.set("TEST_SSH_SCP", p.bin.scp)
        env.set("TEST_SSH_SFTP", p.bin.sftp)
        env.set("TEST_SSH_SK_HELPER", j(p.libexec, "ssh-sk-helper"))
        env.set("TEST_SSH_SFTPSERVER", j(p.libexec, "sftp-server"))
        env.set("TEST_SSH_PKCS11_HELPER", j(p.libexec, "ssh-pkcs11-helper"))
        env.set("TEST_SSH_SSHD", p.sbin.sshd)
        env.set("TEST_SSH_SSHADD", j(p.bin, "ssh-add"))
        env.set("TEST_SSH_SSHAGENT", j(p.bin, "ssh-agent"))
        env.set("TEST_SSH_SSHKEYGEN", j(p.bin, "ssh-keygen"))
        env.set("TEST_SSH_SSHKEYSCAN", j(p.bin, "ssh-keyscan"))
        env.set("TEST_SSH_UNSAFE_PERMISSIONS", "1")
        # Get a free port for the simple tests and skip the complex tests:
        tcp = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        tcp.bind(("", 0))
        host, port = tcp.getsockname()
        tcp.close()
        env.set("TEST_SSH_PORT", port)
        env.set(
            "SKIP_LTESTS",
            "key-options forward-control forwarding "
            "multiplex addrmatch cfgmatch cfgmatchlisten percent",
        )

    def installcheck(self):
        make("-e", "tests", parallel=False)
