# Copyright Spack Project Developers. See COPYRIGHT file for details.
#
# SPDX-License-Identifier: (Apache-2.0 OR MIT)

from spack_repo.builtin.build_systems.cargo import CargoPackage

from spack.package import *


class Surfer(CargoPackage):
    """A waveform viewer with a focus on a snappy usable interface, and extensibility."""

    homepage = "https://surfer-project.org"
    url = "https://gitlab.com/surfer-project/surfer/-/archive/v0.3.0/surfer-v0.3.0.tar.gz"
    git = "https://gitlab.com/surfer-project/surfer.git"

    maintainers("davekeeshan")

    license("EUPL-1.2")

    version("main", branch="main", submodules=True)

    version(
        "0.6.0", tag="v0.6.0", commit="78e71f1e7761750a68fd94c128dd60ad00b220bc", submodules=True
    )
    version(
        "0.5.0", tag="v0.5.0", commit="0be6f8ad869060791ad0864d77f2f842cd27ee65", submodules=True
    )
    version(
        "0.4.0", tag="v0.4.0", commit="9198cc497aec2249ff7459df03fed628c9996578", submodules=True
    )
    version(
        "0.3.0", tag="v0.3.0", commit="1a6b34c44ea0e5089bd55d0bce1297aa1a02e6ef", submodules=True
    )

    depends_on("rust@1.92:", when="@:0.4.0")
    depends_on("rust@1.82:", when="@:0.3.0")
    depends_on("c", type="build")
    depends_on("openssl")

    def build(self, spec, prefix):
        cargo("build", "--release")

    def install(self, spec, prefix):
        cargo("install", "--path", "surfer", "--root", prefix)
