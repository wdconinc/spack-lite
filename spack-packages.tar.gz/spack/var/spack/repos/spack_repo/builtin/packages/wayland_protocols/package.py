# Copyright Spack Project Developers. See COPYRIGHT file for details.
#
# SPDX-License-Identifier: (Apache-2.0 OR MIT)

from spack_repo.builtin.build_systems import meson
from spack_repo.builtin.build_systems.autotools import AutotoolsPackage
from spack_repo.builtin.build_systems.meson import MesonPackage

from spack.package import *


class WaylandProtocols(MesonPackage, AutotoolsPackage):
    """wayland-protocols contains Wayland protocols that add functionality not
    available in the Wayland core protocol. Such protocols either add
    completely new functionality, or extend the functionality of some other
    protocol either in Wayland core, or some other protocol in
    wayland-protocols."""

    homepage = "https://wayland.freedesktop.org/"
    url = "https://gitlab.freedesktop.org/wayland/wayland-protocols/-/archive/1.20/wayland-protocols-1.20.tar.gz"
    list_url = "https://gitlab.freedesktop.org/wayland/wayland-protocols/-/tags"
    git = "https://gitlab.freedesktop.org/wayland/wayland-protocols"

    maintainers("wdconinc")

    build_system(
        conditional("autotools", when="@:1.23"),
        conditional("meson", when="@1.21:"),
        default="meson",
    )

    license("MIT")

    version("1.45", sha256="460dad72a6c84b2a7d80745bee43d96ba117f4e3dfc4d7c45f83f66469ea27df")
    version("1.44", sha256="a8670a81a92a7108deff767a7b725afaa819b6c5a8b857cba41eac6acba783eb")
    version("1.43", sha256="05fc0ff0c6b3081549d8f81c6b584076a20be18e8c2b9be65ae09ce05e5aea9e")
    version("1.42", sha256="5d91dfc40a4086f840552dcda20a39064bc81514577a6639dab1799838ae9b4a")
    version("1.41", sha256="f25b0d00f3c610158b00b57b1b7b6e59c4bfd4d91aed46f24d9eba7acf220788")
    version("1.40", sha256="0d783e6c1fff096d37c4e0fd1f3f14f63c4fdc5c1cf8ec07db2a349ffd56a1d3")
    version("1.39", sha256="42c16435dfc83f320ff727b6d446bb0d4feb361dc11796a2c5d3c0fb6532a517")
    version("1.38", sha256="a6069948458a1d86cea2b33a9735e67d7524118c32c388d75efb881a9e9d2cd9")
    version("1.37", sha256="c3b215084eb4cf318415533554c2c2714e58ed75847d7c3a8e50923215ffbbf3")
    version("1.36", sha256="c839dd4325565fd59a93d6cde17335357328f66983c2e1fb03c33e92d6918b17")
    version("1.35", sha256="6e62dfa92ce82487d107b76064cfe2d7ca107c87c239ea9036a763d79c09105a")
    version("1.34", sha256="cd3cc9dedb838e6fc8f55bbeb688e8569ffac7df53bc59dbfac8acbb39267f05")
    version("1.33", sha256="71a7d2f062d463aa839497ddfac97e4bd3f00aa306e014f94529aa3a2be193a8")
    version("1.32", sha256="444b5d823ad0163dfe505c97ea1a0689ca7e2978a87cf59b03f06573b87db260")
    version("1.31", sha256="04d3f66eca99d638ec8dbfdfdf79334290e22028f7d0b04c7034d9ef18a3248a")
    version("1.30", sha256="1c02ce27d5267c904f2f0d31039265f3e4112f15bf274b1c72bdacd5322f243d")
    version("1.29", sha256="4a85786ae69cd6d53bbe9278572f3c3d6ea342875ea444960edb6089237c3a18")
    version("1.28", sha256="914dfa09e7e866e913b27d2d9bda0e20e728c7b1c831fd3db71538d9f99a4869")
    version("1.27", sha256="6dd6ee86478adf4347f3b8b4f3da62dbe9e44912c9cef21cf99abfe692313df4")
    version("1.26", sha256="fe56386f436a84e97c3b6a61b76306f205a64425900f247ad0048174b9c32d4d")
    version("1.25", sha256="4326e2b5e04e459ab4522e83e19bff101a3faf9b085bcf46b6cabbd392cc4458")
    version("1.24", sha256="71a171f964e4fe25cede281a2939ac5298ddaba9a5dd8a217db66843a532d064")
    version("1.23", sha256="1ffd6f90eb247ff79de50ac10490ed03100572fb571cebef4df9ec74a271b2af")
    version("1.22", sha256="92f3d88192bf5377300dee654a78e296aca20e2f8e1ed95024f0f91513760a94")
    version("1.20", sha256="b59cf0949aeb1f71f7db46b63b1c5a6705ffde8cb5bd194f843fbd9b41308dda")

    with when("build_system=autotools"):
        depends_on("autoconf", type="build")
        depends_on("automake", type="build")
        depends_on("libtool", type="build")
        depends_on("m4", type="build")

    with when("build_system=meson"):
        depends_on("meson@0.55:")
        depends_on("meson@0.58:", when="@1.38:")

    depends_on("pkgconfig", type="build")
    depends_on("wayland")


class MesonBuilder(meson.MesonBuilder):
    def meson_args(self):
        return ["-Dtests={}".format("true" if self.pkg.run_tests else "false")]
