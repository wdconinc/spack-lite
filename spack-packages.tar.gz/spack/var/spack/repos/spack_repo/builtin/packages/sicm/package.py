# Copyright Spack Project Developers. See COPYRIGHT file for details.
#
# SPDX-License-Identifier: (Apache-2.0 OR MIT)

from spack_repo.builtin.build_systems.cmake import CMakePackage

from spack.package import *


class Sicm(CMakePackage):
    """SICM: Simplified Interface to Complex Memory."""

    homepage = "https://github.com/lanl/SICM/"
    git = "https://github.com/lanl/SICM.git"

    tags = ["e4s"]

    license("BSD-2-Clause")

    version("master")

    depends_on("c", type="build")  # generated
    depends_on("cxx", type="build")  # generated
    depends_on("fortran", type="build")  # generated

    depends_on("jemalloc jemalloc_prefix=je_")
    depends_on("numactl")

    def cmake_args(self):
        return []
