# Copyright Spack Project Developers. See COPYRIGHT file for details.
#
# SPDX-License-Identifier: (Apache-2.0 OR MIT)


from spack_repo.builtin.build_systems.python import PythonPackage

from spack.package import *


class PyScoop(PythonPackage):
    """SCOOP (Scalable COncurrent Operations in Python) is a distributed
    task module allowing concurrent parallel programming on various
    environments, from heterogeneous grids to supercomputers."""

    homepage = "https://github.com/soravux/scoop"
    pypi = "scoop/scoop-0.7.1.1.tar.gz"

    license("LGPL-3.0-only")

    version("0.7.2.0", sha256="7658faf751627f5507b6f636794721d89db1771234a36e1378ee6796dd7ee761")
    version("0.7.1.1", sha256="d8b6444c7bac901171e3327a97e241dde63f060354e162a65551fd8083ca62b4")

    depends_on("py-setuptools", type="build")
    depends_on("py-greenlet@0.3.4:", type=("build", "run"))
    depends_on("py-pyzmq@13.1.0:", type=("build", "run"))
