# Copyright Spack Project Developers. See COPYRIGHT file for details.
#
# SPDX-License-Identifier: (Apache-2.0 OR MIT)

from spack_repo.builtin.build_systems.autotools import AutotoolsPackage

from spack.package import *


class Scorep(AutotoolsPackage):
    """The Score-P measurement infrastructure is a highly scalable and
    easy-to-use tool suite for profiling, event tracing, and online analysis
    of HPC applications.
    """

    homepage = "https://www.vi-hps.org/projects/score-p"
    url = "https://perftools.pages.jsc.fz-juelich.de/cicd/scorep/tags/scorep-7.1/scorep-7.1.tar.gz"
    maintainers("wrwilliams")
    version("9.4", sha256="bea58d8c47a7512eca0a5858179377f3f0861f30eafb342a29aa97c05de8f623")
    version("9.3", sha256="5498b31b1d6c04b08a9d408320a7515e884538d248de58b6dd11b48c8f364112")
    version("9.2", sha256="be3eaee99cdd0145e518c1aa959126df45e25b61579a007d062748b2844c499c")
    version("8.4", sha256="7bbde9a0721d27cc6205baf13c1626833bcfbabb1f33b325a2d67976290f7f8a")
    version("8.3", sha256="76c914e6319221c059234597a3bc53da788ed679179ac99c147284dcefb1574a")
    # version 8.2 was immediately superseded before it hit Spack
    version("8.1", sha256="3a40b481fce610871ddf6bdfb88a6d06b9e5eb38c6080faac6d5e44990060a37")
    version("8.0", sha256="4c0f34f20999f92ebe6ca1ff706d0846b8ce6cd537ffbedb49dfaef0faa66311")
    version("7.1", sha256="98dea497982001fb82da3429ca55669b2917a0858c71abe2cfe7cd113381f1f7")
    version("7.0", sha256="68f24a68eb6f94eaecf500e17448f566031946deab74f2cba072ee8368af0996")

    patch(
        "https://gitlab.com/score-p/scorep/-/commit/093ff84f0e155ac1db99bbaa312e028f89affddb.diff",
        when="@7:8.4 +gcc-plugin",
        sha256="d20b3046ba6a89ad9c106bcf372bceb1bd9ab780d4c7dd9e7373f0099b92d933",
    )

    # Variants
    variant("mpi", default=True, description="Enable MPI support")
    variant("papi", default=True, description="Enable PAPI")
    variant("pdt", default=False, description="Enable PDT", when="@:8.4")
    variant("shmem", default=False, description="Enable shmem tracing")
    variant("unwind", default=False, description="Enable sampling via libunwind and lib wrapping")
    variant("cuda", default=False, description="Enable CUDA support")
    variant("hip", default=False, description="Enable ROCm/HIP support", when="@8.0:")
    variant("gcc-plugin", default=True, description="Enable gcc-plugin", when="%gcc")
    variant(
        "llvm-plugin", default=True, description="Enable LLVM compiler plugin", when="@9.0: ^llvm"
    )
    variant(
        "binutils",
        default=True,
        description="Enable debug info lookup via binutils",
        when="^binutils",
    )
    variant("fortran", default=True, description="Enable fortran support")
    variant(
        "mpi_f08", default=True, description="Enable MPI F08 support", when="@9.1: +mpi +fortran"
    )
    variant(
        "gotcha", default=True, description="Enable library wrapping with libgotcha", when="@9:"
    )
    # Dependencies for SCORE-P are quite tight. See the homepage for more
    # information. Starting with scorep 4.0 / cube 4.4, Score-P only depends on
    # two components of cube -- cubew and cubelib.

    # Language dependencies
    depends_on("c", type=("build", "run"))
    depends_on("cxx", type=("build", "run"))
    depends_on("fortran", type=("build", "run"), when="+fortran")

    # SCOREP 9
    depends_on("gotcha@1.0.8:", type="link", when="+gotcha")
    depends_on("otf2@3.1:", when="@9:")
    depends_on("cubew@4.9:", when="@9:")
    depends_on("cubelib@4.9:", when="@9:")
    depends_on("opari2@2.0.9", when="@9:")

    # SCOREP 8
    depends_on("binutils", type="link", when="@8:")
    depends_on("otf2@3:", when="@8:")
    depends_on("cubew@4.8.2:4.8", when="@8.3:8")
    depends_on("cubelib@4.8.2:4.8", when="@8.3:8")
    depends_on("cubew@4.8", when="@8:8.2")
    depends_on("cubelib@4.8", when="@8:8.2")
    # fall through to Score-P 7's OPARI2, no new release
    # SCOREP 7
    depends_on("otf2@2.3:2.3.99", when="@7.0:7")
    depends_on("cubew@4.6:4.7.99", when="@7.0:7")
    depends_on("cubelib@4.6:4.7.99", when="@7.0:7")
    depends_on("opari2@2.0.6:", when="@7:")

    # Conditional dependencies for variants
    depends_on("mpi@2.2:", type=("build", "run"), when="+mpi")
    depends_on("mpi", type=("build", "run"), when="+mpi")
    depends_on("papi", when="+papi")
    depends_on("pdt", when="+pdt")
    depends_on("llvm", when="+unwind")
    depends_on("libunwind", when="+unwind")
    depends_on("cuda@7:", when="@8.0:+cuda")
    depends_on("cuda", when="+cuda")
    depends_on("hip@4.2:", when="+hip")
    depends_on("rocprofiler-dev", when="+hip")
    depends_on("rocm-smi-lib", when="+hip")

    # Score-P requires a case-sensitive file system, and therefore
    # does not work on macOS
    # https://github.com/spack/spack/issues/1609
    conflicts("platform=darwin")
    # Score-P first has support for ROCm 6.x as of v8.4
    conflicts("hip@6.0:", when="@:8.3+hip")

    # Utility function: extract the first directory in `root` where
    # we find `libname`. Used to handle CUDA irregular layouts.
    def find_libpath(self, libname, root):
        libs = find_libraries(libname, root, shared=True, recursive=True)
        if len(libs.directories) == 0:
            return None
        return libs.directories[0]

    # Handle any mapping of Spack compiler names to Score-P args
    # This should continue to exist for backward compatibility
    def clean_compiler(self, compiler):
        renames = {
            "cce": "cray",
            "rocmcc": "amdclang",
            "intel-oneapi-compilers": "oneapi",
            "llvm": "clang",
        }
        if compiler in renames:
            return renames[compiler]
        return compiler

    def configure_args(self):
        spec = self.spec
        config_args = [
            "--with-otf2=%s" % spec["otf2"].prefix.bin,
            "--with-opari2=%s" % spec["opari2"].prefix.bin,
            "--enable-shared",
        ]

        cname = self.clean_compiler(spec.compiler.name)
        config_args.extend(["--with-nocross-compiler-suite={0}".format(cname)])

        if self.version >= Version("4.0"):
            config_args.append("--with-cubew=%s" % spec["cubew"].prefix.bin)
            config_args.append("--with-cubelib=%s" % spec["cubelib"].prefix.bin)
        else:
            config_args.append("--with-cube=%s" % spec["cube"].prefix.bin)

        if "+papi" in spec:
            config_args.append("--with-papi-header=%s" % spec["papi"].prefix.include)
            config_args.append("--with-papi-lib=%s" % spec["papi"].prefix.lib)

        if "+pdt" in spec:
            config_args.append("--with-pdt=%s" % spec["pdt"].prefix.bin)

        config_args.extend(
            self.with_or_without("libunwind", activation_value="prefix", variant="unwind")
        )
        if "+cuda" in spec:
            config_args.append("--with-libcudart=%s" % spec["cuda"].prefix)
            cuda_driver_path = self.find_libpath("libcuda", spec["cuda"].prefix)
            config_args.append("--with-libcuda-lib=%s" % cuda_driver_path)
        config_args.extend(
            self.with_or_without(
                "rocm", activation_value=lambda _: self.spec["hip"].prefix, variant="hip"
            )
        )
        config_args.extend(
            self.with_or_without(
                "libgotcha",
                activation_value=lambda _: self.spec["gotcha"].prefix,
                variant="gotcha",
            )
        )
        config_args.extend(self.enable_or_disable("llvm-plugin"))
        config_args.extend(self.enable_or_disable("gcc-plugin"))
        config_args.extend(self.enable_or_disable("mpi_f08"))
        config_args.extend(self.enable_or_disable("fortran"))

        if "~shmem" in spec:
            config_args.append("--without-shmem")
        # Autodetect shmem in +shmem case
        # Valid --with-shmem values are cray|openshmem|openmpi|openmpi3|sgimpt|
        # sgimptwrapper|spectrum
        # If autodetection fails for +shmem with one of these available to spack, please add
        # a "if spec.satisfies():" clause for said package.

        if spec.satisfies("^[virtuals=mpi] intel-oneapi-mpi"):
            config_args.append("--with-mpi=intel3")
        elif (
            spec.satisfies("^[virtuals=mpi] mpich")
            or spec.satisfies("^[virtuals=mpi] mvapich2")
            or spec.satisfies("^[virtuals=mpi] cray-mpich")
        ):
            config_args.append("--with-mpi=mpich3")
        elif spec.satisfies("^[virtuals=mpi] openmpi") or spec.satisfies(
            "^[virtuals=mpi] hpcx-mpi"
        ):
            config_args.append("--with-mpi=openmpi")
        elif spec.satisfies("~mpi"):
            config_args.append("--without-mpi")
        # Let any +mpi that gets here autodetect, which is default
        # Valid values are bullxmpi|cray|hp|ibmpoe|intel|intel2|intel3|intelpoe|lam|mpibull2
        # |mpich|mpich2|mpich3|mpich4|openmpi|openmpi3|platform|scali|sgimpt|sgimptwrapper
        # |spectrum|sun
        # Score-P does not care overly much as long as the MPI compilers are set
        # (see end of function)
        # but add similar spec.satisfies clauses for any that you need.
        # -- wrwilliams 12/2024
        config_args.extend(
            self.with_or_without(
                "libbfd",
                activation_value=lambda _: self.spec["binutils"].prefix,
                variant="binutils",
            )
        )

        config_args.extend(
            [
                "CFLAGS={0}".format(self.compiler.cc_pic_flag),
                "CXXFLAGS={0}".format(self.compiler.cxx_pic_flag),
            ]
        )

        if spec.satisfies("+mpi"):
            config_args.extend(
                [
                    "MPICC={0}".format(spec["mpi"].mpicc),
                    "MPICXX={0}".format(spec["mpi"].mpicxx),
                    "MPIF77={0}".format(spec["mpi"].mpif77),
                    "MPIFC={0}".format(spec["mpi"].mpifc),
                ]
            )

        return config_args
